// push109.mjs — Sequential GitHub push
// Target: Security.tsx, SmartMoney.tsx, Tokens.tsx (memo + JetBrains Mono)
//         Dashboard.emptystate, Intelligence.emptystate, Derivatives.timestamp
// Run: $env:GH_TOKEN = "ghp_xxx"; node push109.mjs

import https from "https";
import { readFileSync } from "fs";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const OWNER = "wr98-code";
const REPO  = "new-zeromeridian";
const TOKEN = process.env.GH_TOKEN;

if (!TOKEN) {
  console.error("❌ GH_TOKEN env var not set. Exiting.");
  process.exit(1);
}

// ─── base64 encode files ─────────────────────────────────────────────────────
const __dir = dirname(fileURLToPath(import.meta.url));
const b64 = (file) =>
  readFileSync(join(__dir, file)).toString("base64");

// Adjust these paths to match your repo layout
const FILES = [
  {
    fp:  "src/pages/Security.tsx",
    b64: b64("Security.tsx"),
    msg: "push109: Security — memo(), displayName, JetBrains Mono, rgba(), empty state, real API",
  },
  {
    fp:  "src/pages/SmartMoney.tsx",
    b64: b64("SmartMoney.tsx"),
    msg: "push109: SmartMoney — memo(), displayName, JetBrains Mono, rgba(), whale tracker, empty state",
  },
  {
    fp:  "src/pages/Tokens.tsx",
    b64: b64("Tokens.tsx"),
    msg: "push109: Tokens — memo(), displayName, JetBrains Mono, rgba(), sort, search, empty state",
  },
];

// ─── helpers ─────────────────────────────────────────────────────────────────
const delay = (ms) => new Promise((r) => setTimeout(r, ms));

function req(method, path, body) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const opts = {
      hostname: "api.github.com",
      port: 443,
      path,
      method,
      headers: {
        Authorization: `Bearer ${TOKEN}`,
        "Content-Type": "application/json",
        "User-Agent": "zeromeridian-push109",
        Accept: "application/vnd.github+json",
        "Content-Length": Buffer.byteLength(data),
      },
    };
    const r = https.request(opts, (res) => {
      let buf = "";
      res.on("data", (c) => (buf += c));
      res.on("end", () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(buf) }); }
        catch { resolve({ status: res.statusCode, body: buf }); }
      });
    });
    r.on("error", reject);
    r.write(data);
    r.end();
  });
}

async function getSHA(fp) {
  const r = await req("GET", `/repos/${OWNER}/${REPO}/contents/${fp}`, {});
  if (r.status === 200) return r.body.sha;
  return null;
}

async function push(fp, b64content, msg) {
  for (let attempt = 1; attempt <= 3; attempt++) {
    const sha = await getSHA(fp); // fresh SHA per attempt
    const body = { message: msg, content: b64content };
    if (sha) body.sha = sha;

    const r = await req("PUT", `/repos/${OWNER}/${REPO}/contents/${fp}`, body);
    if (r.status === 200 || r.status === 201) {
      console.log(`✅ [${r.status}] ${fp}`);
      return true;
    }
    if (r.status === 409) {
      console.warn(`⚠  409 Conflict on ${fp} — retry ${attempt}/3`);
      await delay(2500 * attempt);
      continue;
    }
    console.error(`❌ [${r.status}] ${fp}`, r.body?.message ?? "");
    return false;
  }
  return false;
}

// ─── SEQUENTIAL push — NO Promise.all ────────────────────────────────────────
console.log(`\n🚀 push109 starting — ${FILES.length} files\n`);

for (const f of FILES) {
  const ok = await push(f.fp, f.b64, f.msg);
  if (!ok) {
    console.error(`\n💥 push109 FAILED at ${f.fp}. Aborting remaining files.`);
    process.exit(1);
  }
  await delay(600); // small gap between writes
}

console.log("\n✅ push109 complete. Cloudflare Pages deploy triggered.");
console.log("🔗 https://new-zeromeridian.pages.dev");
